﻿using AllatAdmin.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllatAdmin
{
    public partial class MegrUjEdit : Form
    {
        private Megrendelesek m;
        public MegrUjEdit(Megrendelesek m)
        {
            this.m = m;
            InitializeComponent();

        }

      
    }
}
