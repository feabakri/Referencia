﻿namespace AllatAdmin
{
    partial class AllatUjEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxfajta = new System.Windows.Forms.TextBox();
            this.textBoxdarab = new System.Windows.Forms.TextBox();
            this.textBoxnev = new System.Windows.Forms.TextBox();
            this.textBoxkor = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonrendben = new System.Windows.Forms.Button();
            this.buttonmegse = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxAllatkert = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // textBoxfajta
            // 
            this.textBoxfajta.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxfajta.Location = new System.Drawing.Point(259, 55);
            this.textBoxfajta.Name = "textBoxfajta";
            this.textBoxfajta.Size = new System.Drawing.Size(121, 20);
            this.textBoxfajta.TabIndex = 0;
            // 
            // textBoxdarab
            // 
            this.textBoxdarab.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxdarab.Location = new System.Drawing.Point(259, 177);
            this.textBoxdarab.Name = "textBoxdarab";
            this.textBoxdarab.Size = new System.Drawing.Size(121, 20);
            this.textBoxdarab.TabIndex = 1;
            // 
            // textBoxnev
            // 
            this.textBoxnev.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxnev.Location = new System.Drawing.Point(259, 138);
            this.textBoxnev.Name = "textBoxnev";
            this.textBoxnev.Size = new System.Drawing.Size(121, 20);
            this.textBoxnev.TabIndex = 2;
            // 
            // textBoxkor
            // 
            this.textBoxkor.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxkor.Location = new System.Drawing.Point(259, 97);
            this.textBoxkor.Name = "textBoxkor";
            this.textBoxkor.Size = new System.Drawing.Size(121, 20);
            this.textBoxkor.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(152, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Fajta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(152, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Darab";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(152, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Név";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(152, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Kor";
            // 
            // buttonrendben
            // 
            this.buttonrendben.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonrendben.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonrendben.Location = new System.Drawing.Point(155, 282);
            this.buttonrendben.Name = "buttonrendben";
            this.buttonrendben.Size = new System.Drawing.Size(118, 36);
            this.buttonrendben.TabIndex = 8;
            this.buttonrendben.Text = "Rendben";
            this.buttonrendben.UseVisualStyleBackColor = true;
            this.buttonrendben.Click += new System.EventHandler(this.buttonrendben_Click);
            // 
            // buttonmegse
            // 
            this.buttonmegse.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonmegse.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonmegse.Location = new System.Drawing.Point(355, 282);
            this.buttonmegse.Name = "buttonmegse";
            this.buttonmegse.Size = new System.Drawing.Size(101, 36);
            this.buttonmegse.TabIndex = 9;
            this.buttonmegse.Text = "Mégse";
            this.buttonmegse.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(152, 219);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "Állatkert";
            // 
            // comboBoxAllatkert
            // 
            this.comboBoxAllatkert.FormattingEnabled = true;
            this.comboBoxAllatkert.Location = new System.Drawing.Point(259, 219);
            this.comboBoxAllatkert.Name = "comboBoxAllatkert";
            this.comboBoxAllatkert.Size = new System.Drawing.Size(121, 21);
            this.comboBoxAllatkert.TabIndex = 13;
            // 
            // AllatUjEdit
            // 
            this.AcceptButton = this.buttonrendben;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.comboBoxAllatkert);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.buttonmegse);
            this.Controls.Add(this.buttonrendben);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxkor);
            this.Controls.Add(this.textBoxnev);
            this.Controls.Add(this.textBoxdarab);
            this.Controls.Add(this.textBoxfajta);
            this.Name = "AllatUjEdit";
            this.Text = "AllatUjEdit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxfajta;
        private System.Windows.Forms.TextBox textBoxdarab;
        private System.Windows.Forms.TextBox textBoxnev;
        private System.Windows.Forms.TextBox textBoxkor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonrendben;
        private System.Windows.Forms.Button buttonmegse;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxAllatkert;
    }
}