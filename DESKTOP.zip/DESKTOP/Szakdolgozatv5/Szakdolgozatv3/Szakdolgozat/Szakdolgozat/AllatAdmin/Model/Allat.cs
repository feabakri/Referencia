﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatAdmin.Model
{
    public partial class Allat
    {
        private int azonosito;
        private string fajta;
        private string nev;
        private int kor;
        private int darab;
        private string allatkert;

        public Allat(int azonosito, string fajta, int kor, string nev, int darab, string allatkert)
        {
            this.azonosito = azonosito;
            this.fajta = fajta;
            this.kor = kor;
            this.nev = nev;
            this.allatkert = allatkert;
            this.darab = darab;
        }

        public Allat(int azonosito)
        {
            this.azonosito = azonosito;

        }

        public void setazonosito(int azonosito)
        {
            this.azonosito = azonosito;
        }

        public void setAllatkert(string allatkert)
        {
            this.allatkert = allatkert;
        }

        public string getAllatkert()
        {
            return allatkert;
        }

        public void setnev(string nev)
        {
            this.nev = nev;
        }
        public void setfajta(string fajta)
        {
            this.fajta = fajta;
        }
        public void setkor(int kor)
        {
            this.kor = kor;
        }
        public void setdarab(int darab)
        {
            this.darab = darab;
        }

        public int getazonosito()
        {
            return azonosito;
        }
        public string getnev()
        {
            return nev;
        }
        public string getfajta()
        {
            return fajta;
        }
        public int getkor()
        {
            return kor;
        }
        public int getdarab()
        {
            return darab;
        }

        public override string ToString()
        {
            return azonosito + " " + fajta + " " + kor + " " + nev + " " + darab + " " + allatkert;
        }


    }
}
