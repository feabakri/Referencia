﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatAdmin.MyException
{
    class AllatServiceException:Exception
    {
        public AllatServiceException(string message)
            : base(message)
        { }
    }
}
