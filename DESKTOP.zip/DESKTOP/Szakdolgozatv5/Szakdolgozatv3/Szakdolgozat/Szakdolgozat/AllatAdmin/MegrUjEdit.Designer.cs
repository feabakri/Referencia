﻿namespace AllatAdmin
{
    partial class MegrUjEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxtipus = new System.Windows.Forms.TextBox();
            this.textBoxnev = new System.Windows.Forms.TextBox();
            this.textBoxkor = new System.Windows.Forms.TextBox();
            this.textBoxfajta = new System.Windows.Forms.TextBox();
            this.textBoxdarab = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonrendben = new System.Windows.Forms.Button();
            this.buttonmegse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxtipus
            // 
            this.textBoxtipus.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxtipus.Location = new System.Drawing.Point(264, 52);
            this.textBoxtipus.Name = "textBoxtipus";
            this.textBoxtipus.Size = new System.Drawing.Size(152, 20);
            this.textBoxtipus.TabIndex = 0;
            // 
            // textBoxnev
            // 
            this.textBoxnev.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxnev.Location = new System.Drawing.Point(264, 178);
            this.textBoxnev.Name = "textBoxnev";
            this.textBoxnev.Size = new System.Drawing.Size(152, 20);
            this.textBoxnev.TabIndex = 1;
            // 
            // textBoxkor
            // 
            this.textBoxkor.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxkor.Location = new System.Drawing.Point(264, 138);
            this.textBoxkor.Name = "textBoxkor";
            this.textBoxkor.Size = new System.Drawing.Size(152, 20);
            this.textBoxkor.TabIndex = 2;
            // 
            // textBoxfajta
            // 
            this.textBoxfajta.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxfajta.Location = new System.Drawing.Point(264, 93);
            this.textBoxfajta.Name = "textBoxfajta";
            this.textBoxfajta.Size = new System.Drawing.Size(152, 20);
            this.textBoxfajta.TabIndex = 3;
            // 
            // textBoxdarab
            // 
            this.textBoxdarab.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxdarab.Location = new System.Drawing.Point(264, 214);
            this.textBoxdarab.Name = "textBoxdarab";
            this.textBoxdarab.Size = new System.Drawing.Size(152, 20);
            this.textBoxdarab.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(118, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Típus";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(118, 214);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Darab";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(118, 178);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Név";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(118, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Kor";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(118, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Fajta";
            // 
            // buttonrendben
            // 
            this.buttonrendben.Location = new System.Drawing.Point(178, 276);
            this.buttonrendben.Name = "buttonrendben";
            this.buttonrendben.Size = new System.Drawing.Size(120, 44);
            this.buttonrendben.TabIndex = 10;
            this.buttonrendben.Text = "Rendben";
            this.buttonrendben.UseVisualStyleBackColor = true;
            // 
            // buttonmegse
            // 
            this.buttonmegse.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonmegse.Location = new System.Drawing.Point(343, 276);
            this.buttonmegse.Name = "buttonmegse";
            this.buttonmegse.Size = new System.Drawing.Size(120, 44);
            this.buttonmegse.TabIndex = 11;
            this.buttonmegse.Text = "Mégse";
            this.buttonmegse.UseVisualStyleBackColor = true;
            // 
            // MegrUjEdit
            // 
            this.AcceptButton = this.buttonrendben;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.CancelButton = this.buttonmegse;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonmegse);
            this.Controls.Add(this.buttonrendben);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxdarab);
            this.Controls.Add(this.textBoxfajta);
            this.Controls.Add(this.textBoxkor);
            this.Controls.Add(this.textBoxnev);
            this.Controls.Add(this.textBoxtipus);
            this.Name = "MegrUjEdit";
            this.Text = "MegrUjEdit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxtipus;
        private System.Windows.Forms.TextBox textBoxnev;
        private System.Windows.Forms.TextBox textBoxkor;
        private System.Windows.Forms.TextBox textBoxfajta;
        private System.Windows.Forms.TextBox textBoxdarab;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonrendben;
        private System.Windows.Forms.Button buttonmegse;
    }
}