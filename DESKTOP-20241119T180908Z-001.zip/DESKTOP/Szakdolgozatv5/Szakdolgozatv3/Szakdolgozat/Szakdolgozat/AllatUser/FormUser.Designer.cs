﻿namespace AllatUser
{
    partial class FormUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Állatok = new System.Windows.Forms.TabPage();
            this.dataGridViewAllatok = new System.Windows.Forms.DataGridView();
            this.dataGridViewAllatkertek = new System.Windows.Forms.DataGridView();
            this.Megrendelések = new System.Windows.Forms.TabPage();
            this.dataGridViewusermegr = new System.Windows.Forms.DataGridView();
            this.buttonbetoltes = new System.Windows.Forms.Button();
            this.buttonkilepes = new System.Windows.Forms.Button();
            this.buttontorles = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.Állatok.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllatok)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllatkertek)).BeginInit();
            this.Megrendelések.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewusermegr)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Állatok);
            this.tabControl1.Controls.Add(this.Megrendelések);
            this.tabControl1.Location = new System.Drawing.Point(28, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(730, 552);
            this.tabControl1.TabIndex = 0;
            // 
            // Állatok
            // 
            this.Állatok.BackColor = System.Drawing.Color.SeaGreen;
            this.Állatok.Controls.Add(this.dataGridViewAllatok);
            this.Állatok.Controls.Add(this.dataGridViewAllatkertek);
            this.Állatok.Location = new System.Drawing.Point(4, 22);
            this.Állatok.Name = "Állatok";
            this.Állatok.Padding = new System.Windows.Forms.Padding(3);
            this.Állatok.Size = new System.Drawing.Size(722, 526);
            this.Állatok.TabIndex = 0;
            this.Állatok.Text = "Állatok";
            // 
            // dataGridViewAllatok
            // 
            this.dataGridViewAllatok.AllowUserToAddRows = false;
            this.dataGridViewAllatok.AllowUserToDeleteRows = false;
            this.dataGridViewAllatok.BackgroundColor = System.Drawing.Color.Moccasin;
            this.dataGridViewAllatok.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAllatok.Location = new System.Drawing.Point(6, 282);
            this.dataGridViewAllatok.Name = "dataGridViewAllatok";
            this.dataGridViewAllatok.ReadOnly = true;
            this.dataGridViewAllatok.Size = new System.Drawing.Size(710, 234);
            this.dataGridViewAllatok.TabIndex = 1;
            // 
            // dataGridViewAllatkertek
            // 
            this.dataGridViewAllatkertek.AllowUserToAddRows = false;
            this.dataGridViewAllatkertek.AllowUserToDeleteRows = false;
            this.dataGridViewAllatkertek.BackgroundColor = System.Drawing.Color.Moccasin;
            this.dataGridViewAllatkertek.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAllatkertek.Location = new System.Drawing.Point(6, 22);
            this.dataGridViewAllatkertek.MultiSelect = false;
            this.dataGridViewAllatkertek.Name = "dataGridViewAllatkertek";
            this.dataGridViewAllatkertek.ReadOnly = true;
            this.dataGridViewAllatkertek.Size = new System.Drawing.Size(710, 234);
            this.dataGridViewAllatkertek.TabIndex = 0;
            this.dataGridViewAllatkertek.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAllatkertek_CellClick);
            // 
            // Megrendelések
            // 
            this.Megrendelések.Controls.Add(this.dataGridViewusermegr);
            this.Megrendelések.Location = new System.Drawing.Point(4, 22);
            this.Megrendelések.Name = "Megrendelések";
            this.Megrendelések.Padding = new System.Windows.Forms.Padding(3);
            this.Megrendelések.Size = new System.Drawing.Size(722, 526);
            this.Megrendelések.TabIndex = 1;
            this.Megrendelések.Text = "Megrendelések";
            this.Megrendelések.UseVisualStyleBackColor = true;
            // 
            // dataGridViewusermegr
            // 
            this.dataGridViewusermegr.BackgroundColor = System.Drawing.Color.Moccasin;
            this.dataGridViewusermegr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewusermegr.Location = new System.Drawing.Point(6, 22);
            this.dataGridViewusermegr.Name = "dataGridViewusermegr";
            this.dataGridViewusermegr.Size = new System.Drawing.Size(710, 214);
            this.dataGridViewusermegr.TabIndex = 0;
            // 
            // buttonbetoltes
            // 
            this.buttonbetoltes.Location = new System.Drawing.Point(927, 56);
            this.buttonbetoltes.Name = "buttonbetoltes";
            this.buttonbetoltes.Size = new System.Drawing.Size(116, 33);
            this.buttonbetoltes.TabIndex = 1;
            this.buttonbetoltes.Text = "Adatok betöltése";
            this.buttonbetoltes.UseVisualStyleBackColor = true;
            this.buttonbetoltes.Click += new System.EventHandler(this.buttonbetoltes_Click);
            // 
            // buttonkilepes
            // 
            this.buttonkilepes.Location = new System.Drawing.Point(927, 531);
            this.buttonkilepes.Name = "buttonkilepes";
            this.buttonkilepes.Size = new System.Drawing.Size(116, 33);
            this.buttonkilepes.TabIndex = 2;
            this.buttonkilepes.Text = "Kilépés";
            this.buttonkilepes.UseVisualStyleBackColor = true;
            this.buttonkilepes.Click += new System.EventHandler(this.buttonkilepes_Click);
            // 
            // buttontorles
            // 
            this.buttontorles.Location = new System.Drawing.Point(927, 105);
            this.buttontorles.Name = "buttontorles";
            this.buttontorles.Size = new System.Drawing.Size(116, 33);
            this.buttontorles.TabIndex = 3;
            this.buttontorles.Text = "Törlés";
            this.buttontorles.UseVisualStyleBackColor = true;
            this.buttontorles.Click += new System.EventHandler(this.buttontorles_Click);
            // 
            // FormUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(1055, 576);
            this.Controls.Add(this.buttontorles);
            this.Controls.Add(this.buttonkilepes);
            this.Controls.Add(this.buttonbetoltes);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormUser";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.Állatok.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllatok)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllatkertek)).EndInit();
            this.Megrendelések.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewusermegr)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Állatok;
        private System.Windows.Forms.DataGridView dataGridViewAllatkertek;
        private System.Windows.Forms.TabPage Megrendelések;
        private System.Windows.Forms.Button buttonbetoltes;
        private System.Windows.Forms.Button buttonkilepes;
        private System.Windows.Forms.Button buttontorles;
        private System.Windows.Forms.DataGridView dataGridViewusermegr;
        private System.Windows.Forms.DataGridView dataGridViewAllatok;
    }
}

