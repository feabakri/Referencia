﻿using AllatUser.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllatUser
{
    public partial class AllatUjEdit : Form
    {
        private Allat a;
        public AllatUjEdit(Allat a, List<string> allatkertek)
        {
            InitializeComponent();
            this.a = a;
            allatkertek.RemoveAt(0);
            comboBoxallatkert.DataSource = null;
            comboBoxallatkert.DataSource = allatkertek;
            showData();
        }

        private void showData()
        {
            if (a.getfajta() != null)
            {
                textBoxfajta.Text = a.getfajta();
                textBoxkor.Text = a.getkor().ToString();
                textBoxnev.Text = a.getnev();
                textBoxdarab.Text = a.getdarab().ToString();
                comboBoxallatkert.Text = a.getAllatkert().ToString();
            }
        }
        public Allat AddAllat()
        {
            return a;
        }

        private void buttonrendben_Click(object sender, EventArgs e)
        {
            a.setnev(textBoxnev.Text);
            a.setfajta(textBoxfajta.Text);
            a.setkor(Convert.ToInt32(textBoxkor.Text));
            a.setdarab(Convert.ToInt32(textBoxdarab.Text));
            a.setAllatkert(comboBoxallatkert.SelectedItem.ToString());
        }
    }
}
