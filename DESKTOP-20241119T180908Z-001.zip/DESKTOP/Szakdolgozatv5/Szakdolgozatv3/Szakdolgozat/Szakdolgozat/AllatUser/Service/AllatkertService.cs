﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AllatUser.Repository;
using System.Data;

namespace AllatUser.Service
{
    public class AllatkertService
    {
        AllatkertRepo ar;

        public AllatkertService()
        {
            ar = new AllatkertRepo();
        }

        public DataTable loadAllatkertData()
        {
            return ar.loadAllatkertekFromDataTable();
        }
    }
}
