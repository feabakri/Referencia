﻿using AllatUser.Model;
using AllatUser.MyException;
using AllatUser.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatUser.Service
{
   public class MegrendelesekService
    {
        MegrendelesekRepo mr;

        public MegrendelesekService()
        {
            mr = new MegrendelesekRepo();
        }

        public DataTable LoadMegrendelesData()
        {
            return mr.getMegrendeleseksDataTable();
        }
        


        public void deleteMegrendeles(Megrendelesek megrendeles)
        {
            if (!mr.checkExist(megrendeles))
            {
                throw new MegrendelesekServiceException(megrendeles.getazonosito() + " nincs ilyen azonosítójú megrendelés");
            }
            else
            {
                mr.delMegr(megrendeles);
            }

        }

        internal int nextID()
        {
            return mr.nextID();
        }
    }
}
