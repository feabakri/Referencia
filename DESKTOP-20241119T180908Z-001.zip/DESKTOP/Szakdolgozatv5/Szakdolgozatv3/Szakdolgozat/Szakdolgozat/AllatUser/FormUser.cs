﻿using AllatUser.Model;
using AllatUser.MyException;
using AllatUser.Service;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllatUser
{
    public partial class FormUser : Form
    {
        AllatService asc;
        AllatkertService aks;
        MegrendelesekService msc;

        public FormUser()
        {
            asc = new AllatService();
            aks = new AllatkertService();
            msc = new MegrendelesekService();
            InitializeComponent();
            dataGridViewAllatkertek.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridViewAllatkertek.AllowUserToAddRows = false;
            dataGridViewAllatkertek.ClearSelection();
            dataGridViewAllatkertek.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewAllatok.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridViewAllatok.AllowUserToAddRows = false;
            dataGridViewAllatok.ClearSelection();
            dataGridViewAllatok.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewusermegr.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridViewusermegr.AllowUserToAddRows = false;
            dataGridViewusermegr.ClearSelection();
            dataGridViewusermegr.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


        }

        private void buttonbetoltes_Click(object sender, EventArgs e)
        {
               if (dataGridViewAllatkertek.DataSource != null)
               {
                        dataGridViewAllatkertek.DataSource = null;
               }
            dataGridViewAllatkertek.DataSource = aks.loadAllatkertData();
            if (dataGridViewusermegr.DataSource != null)
            {
                dataGridViewusermegr.DataSource = null;
            }
            dataGridViewusermegr.DataSource = msc.LoadMegrendelesData();
            
        }


        private void buttonkilepes_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttontorles_Click(object sender, EventArgs e)
        {
            try
            {
                if (tabControl1.SelectedTab.Text == "Állatok")
                {

                    int id = Convert.ToInt32(dataGridViewAllatok.SelectedRows[0].Cells["Azonosito"].Value);
                    Allat ng = new Allat(id,
                        dataGridViewAllatok.SelectedRows[0].Cells["Fajta"].Value.ToString(),
                        Convert.ToInt32(dataGridViewAllatok.SelectedRows[0].Cells["Kor"].Value),
                        dataGridViewAllatok.SelectedRows[0].Cells["Nev"].Value.ToString(),
                        Convert.ToInt32(dataGridViewAllatok.SelectedRows[0].Cells["Darab"].Value),
                        dataGridViewAllatok.SelectedRows[0].Cells["Allatkert"].Value.ToString());
                    asc.deleteAllat(ng);
                    dataGridViewAllatok.DataSource = null;
                    dataGridViewAllatok.DataSource = aks.loadAllatkertData();

                }
                else if (tabControl1.SelectedTab.Text == "Megrendelések")
                {

                    int id = Convert.ToInt32(dataGridViewusermegr.SelectedRows[0].Cells["Azonosító"].Value);
                    Megrendelesek mr = new Megrendelesek(id,
                         dataGridViewusermegr.SelectedRows[0].Cells["Típus"].Value.ToString(),
                         dataGridViewusermegr.SelectedRows[0].Cells["Fajta"].Value.ToString(),
                            Convert.ToInt32(dataGridViewusermegr.SelectedRows[0].Cells["Kor"].Value),
                         dataGridViewusermegr.SelectedRows[0].Cells["Név"].Value.ToString(),
                        Convert.ToInt32(dataGridViewusermegr.SelectedRows[0].Cells["Darab"].Value));
                    msc.deleteMegrendeles(mr);
                    dataGridViewusermegr.DataSource = null;
                    dataGridViewusermegr.DataSource = msc.LoadMegrendelesData();
                }
                else
                    MessageBox.Show("Válasszon tabot");
            }
            catch (AllatServiceException alc)
            {
                
            }
        }

        private void dataGridViewAllatkertek_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewAllatkertek.SelectedRows.Count > 0)
            {
                try
                {
                    string allatkert = dataGridViewAllatkertek.SelectedRows[0].Cells["Név"].Value.ToString();
                    if (dataGridViewAllatok.DataSource != null)
                        dataGridViewAllatok.DataSource = null;
                    dataGridViewAllatok.DataSource = asc.loadAllatDataSzuressel(allatkert);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, ex.Message, "Csatlakozási hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);


                }


            }
            else
                MessageBox.Show(this, "Nincs állatkert kijelölve!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);












        }
    }
}
    

