﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AllatUser.Model;
using ConnectToMysqlDatabase;
using MySql.Data;

namespace AllatUser.Repository
{
    public class AllatkertRepo
    {
        List<Allatkert> allatkertek;

        public AllatkertRepo()
        {            
            allatkertek = new List<Allatkert>();


        }



        public void fillAllatkertekFromDB()
        {
            MySQLDatabase md = new MySQLDatabase();
            MySQLDatabaseInterface mdi = md.getDatabaseInterface();
            mdi.open();
            string query = "SELECT id,nev,cim,elerhetoseg FROM allatkert";
            DataTable dtAllatkertek = mdi.getToDataTable(query);
            mdi.close();

            foreach (DataRow row in dtAllatkertek.Rows)
            {
                int id = Convert.ToInt32(row["id"].ToString());
                string nev = row["nev"].ToString();
                string cim = row["cim"].ToString();
                string elerhetoseg = row["elerhetoseg"].ToString();
                Allatkert a = new Allatkert(id, nev, cim, elerhetoseg);
                allatkertek.Add(a);
            }
        }



        public DataTable loadAllatkertekFromDataTable()
        {
            allatkertek.Clear();
            fillAllatkertekFromDB();
            DataTable allatkertekDT = new DataTable();
            allatkertekDT.Columns.Add("Id", typeof(int));
            allatkertekDT.Columns.Add("Név", typeof(string));
            allatkertekDT.Columns.Add("Cím", typeof(string));
            allatkertekDT.Columns.Add("Elérhetőség", typeof(string));
            foreach (Allatkert a in allatkertek)
            {
                allatkertekDT.Rows.Add(a.getAzonosito(),a.getNev(),a.getCim(),a.getElerhetoseg());

            }
            return allatkertekDT;




        }





    }
}
