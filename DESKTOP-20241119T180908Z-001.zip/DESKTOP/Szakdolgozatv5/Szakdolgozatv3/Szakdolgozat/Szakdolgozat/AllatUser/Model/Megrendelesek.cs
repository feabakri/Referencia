﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatUser.Model
{
    public class Megrendelesek
    {
        private int azonosito;
        private string tipus;
        private string fajta;
        private string nev;
        private int kor;
        private int darab;

        public Megrendelesek(int azonosito, string tipus, string fajta, int kor, string nev, int darab)
        {
            this.azonosito = azonosito;
            this.fajta = fajta;
            this.kor = kor;
            this.nev = nev;
            this.tipus = tipus;
            this.darab = darab;
        }

        public Megrendelesek(int azonosito)
        {
            this.azonosito = azonosito;

        }

        public void setazonosito(int azonosito)
        {
            this.azonosito = azonosito;
        }

        public void settipus(string tipus)
        {
            this.tipus = tipus;
        }
        public void setnev(string nev)
        {
            this.nev = nev;
        }
        public void setfajta(string fajta)
        {
            this.fajta = fajta;
        }
        public void setkor(int kor)
        {
            this.kor = kor;
        }
        public void setdarab(int darab)
        {
            this.darab = darab;
        }

        public int getazonosito()
        {
            return azonosito;
        }
        public string getnev()
        {
            return nev;
        }
        public string getfajta()
        {
            return fajta;
        }
        public string getipus()
        {
            return tipus;
        }

        public int getkor()
        {
            return kor;
        }
        public int getdarab()
        {
            return darab;
        }

        public override string ToString()
        {
            return azonosito + " " + tipus + " " + fajta + " " + kor + "" + nev + "" + darab;
        }

        

        public string getDeleteQuery()
        {
            string queryDelete = "DELETE FROM `megrendelesek` WHERE azonosito= " + getazonosito() + ";";
            return queryDelete;
        }
    }
}
