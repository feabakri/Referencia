﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatUser.Model
{
    public class Allatkert
    {
        private int azonosito;
        private string nev;
        private string cim;
        private string elerhetoseg;
     

       

        public Allatkert(int azonosito)
        {
            this.azonosito = azonosito;

        }

        public Allatkert(int azonosito, string nev, string cim, string elerhetoseg)
        {
            this.azonosito = azonosito;
            this.nev = nev;
            this.cim = cim;
            this.elerhetoseg = elerhetoseg;
        }


        public void setAzonosito(int azonosito)
        {
            this.azonosito = azonosito;
        }
        public void setNev(string nev)
        {
            this.nev = nev;
        }
        public void setCim(string cim)
        {
            this.cim = cim;
        }
        public void setelErhetoseg(string elerhetoseg)
        {
            this.elerhetoseg = elerhetoseg;
        }
        public string getNev()
        {
            return nev;
        }
        public string getCim()
        {
            return cim;
        }
        public string getElerhetoseg()
        {
            return elerhetoseg;
        }
        public int getAzonosito()
        {
            return azonosito;
        }


        public override string ToString()
        {
            return azonosito + " " + nev + " " + cim + " " + elerhetoseg;
        }








    }
}
