﻿namespace AllatUser
{
    partial class AllatUjEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxfajta = new System.Windows.Forms.TextBox();
            this.textBoxdarab = new System.Windows.Forms.TextBox();
            this.textBoxnev = new System.Windows.Forms.TextBox();
            this.textBoxkor = new System.Windows.Forms.TextBox();
            this.comboBoxallatkert = new System.Windows.Forms.ComboBox();
            this.buttonrendben = new System.Windows.Forms.Button();
            this.buttonmegse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(163, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(163, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(163, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(163, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(163, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "label5";
            // 
            // textBoxfajta
            // 
            this.textBoxfajta.Location = new System.Drawing.Point(245, 64);
            this.textBoxfajta.Name = "textBoxfajta";
            this.textBoxfajta.Size = new System.Drawing.Size(158, 20);
            this.textBoxfajta.TabIndex = 5;
            // 
            // textBoxdarab
            // 
            this.textBoxdarab.Location = new System.Drawing.Point(245, 189);
            this.textBoxdarab.Name = "textBoxdarab";
            this.textBoxdarab.Size = new System.Drawing.Size(158, 20);
            this.textBoxdarab.TabIndex = 6;
            // 
            // textBoxnev
            // 
            this.textBoxnev.Location = new System.Drawing.Point(245, 153);
            this.textBoxnev.Name = "textBoxnev";
            this.textBoxnev.Size = new System.Drawing.Size(158, 20);
            this.textBoxnev.TabIndex = 7;
            // 
            // textBoxkor
            // 
            this.textBoxkor.Location = new System.Drawing.Point(245, 111);
            this.textBoxkor.Name = "textBoxkor";
            this.textBoxkor.Size = new System.Drawing.Size(158, 20);
            this.textBoxkor.TabIndex = 8;
            // 
            // comboBoxallatkert
            // 
            this.comboBoxallatkert.FormattingEnabled = true;
            this.comboBoxallatkert.Location = new System.Drawing.Point(245, 221);
            this.comboBoxallatkert.Name = "comboBoxallatkert";
            this.comboBoxallatkert.Size = new System.Drawing.Size(158, 21);
            this.comboBoxallatkert.TabIndex = 9;
            // 
            // buttonrendben
            // 
            this.buttonrendben.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonrendben.Location = new System.Drawing.Point(133, 298);
            this.buttonrendben.Name = "buttonrendben";
            this.buttonrendben.Size = new System.Drawing.Size(133, 48);
            this.buttonrendben.TabIndex = 10;
            this.buttonrendben.Text = "Rendben";
            this.buttonrendben.UseVisualStyleBackColor = true;
            this.buttonrendben.Click += new System.EventHandler(this.buttonrendben_Click);
            // 
            // buttonmegse
            // 
            this.buttonmegse.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonmegse.Location = new System.Drawing.Point(323, 298);
            this.buttonmegse.Name = "buttonmegse";
            this.buttonmegse.Size = new System.Drawing.Size(133, 48);
            this.buttonmegse.TabIndex = 11;
            this.buttonmegse.Text = "Mégse";
            this.buttonmegse.UseVisualStyleBackColor = true;
            // 
            // AllatUjEdit
            // 
            this.AcceptButton = this.buttonrendben;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonmegse);
            this.Controls.Add(this.buttonrendben);
            this.Controls.Add(this.comboBoxallatkert);
            this.Controls.Add(this.textBoxkor);
            this.Controls.Add(this.textBoxnev);
            this.Controls.Add(this.textBoxdarab);
            this.Controls.Add(this.textBoxfajta);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AllatUjEdit";
            this.Text = "AllatUjEdit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxfajta;
        private System.Windows.Forms.TextBox textBoxdarab;
        private System.Windows.Forms.TextBox textBoxnev;
        private System.Windows.Forms.TextBox textBoxkor;
        private System.Windows.Forms.ComboBox comboBoxallatkert;
        private System.Windows.Forms.Button buttonrendben;
        private System.Windows.Forms.Button buttonmegse;
    }
}