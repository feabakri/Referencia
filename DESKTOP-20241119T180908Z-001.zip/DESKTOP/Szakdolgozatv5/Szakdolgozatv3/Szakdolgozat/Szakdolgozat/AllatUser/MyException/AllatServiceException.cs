﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatUser.MyException
{
    public class AllatServiceException:Exception
    {
        public AllatServiceException(string message)
           : base(message)
        { }
    }
}
