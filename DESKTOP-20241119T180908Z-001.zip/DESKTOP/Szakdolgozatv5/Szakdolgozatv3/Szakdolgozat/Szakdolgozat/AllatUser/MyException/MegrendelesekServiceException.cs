﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatUser.MyException
{
    public class MegrendelesekServiceException:Exception
    {
        public MegrendelesekServiceException(string message)
           : base(message)
        { }
    }
}
