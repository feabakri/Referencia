﻿namespace AllatAdmin
{
    partial class FormKezdo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Állatok = new System.Windows.Forms.TabPage();
            this.dataGridViewAllatok = new System.Windows.Forms.DataGridView();
            this.Felhasználók = new System.Windows.Forms.TabPage();
            this.dataGridViewfelhasznalok = new System.Windows.Forms.DataGridView();
            this.buttonbetoltes = new System.Windows.Forms.Button();
            this.buttonkilepes = new System.Windows.Forms.Button();
            this.errorProviderhozzaad = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvidermodositas = new System.Windows.Forms.ErrorProvider(this.components);
            this.buttontorles = new System.Windows.Forms.Button();
            this.buttonmodositas = new System.Windows.Forms.Button();
            this.buttonUj = new System.Windows.Forms.Button();
            this.comboBoxSzuresAllatkert = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.Állatok.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllatok)).BeginInit();
            this.Felhasználók.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewfelhasznalok)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderhozzaad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvidermodositas)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Állatok);
            this.tabControl1.Controls.Add(this.Felhasználók);
            this.tabControl1.Location = new System.Drawing.Point(31, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(673, 424);
            this.tabControl1.TabIndex = 0;
            // 
            // Állatok
            // 
            this.Állatok.Controls.Add(this.dataGridViewAllatok);
            this.Állatok.Location = new System.Drawing.Point(4, 22);
            this.Állatok.Name = "Állatok";
            this.Állatok.Padding = new System.Windows.Forms.Padding(3);
            this.Állatok.Size = new System.Drawing.Size(665, 398);
            this.Állatok.TabIndex = 0;
            this.Állatok.Text = "Állatok";
            this.Állatok.UseVisualStyleBackColor = true;
            // 
            // dataGridViewAllatok
            // 
            this.dataGridViewAllatok.BackgroundColor = System.Drawing.Color.Moccasin;
            this.dataGridViewAllatok.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAllatok.Location = new System.Drawing.Point(-23, 0);
            this.dataGridViewAllatok.Name = "dataGridViewAllatok";
            this.dataGridViewAllatok.Size = new System.Drawing.Size(715, 402);
            this.dataGridViewAllatok.TabIndex = 0;
            // 
            // Felhasználók
            // 
            this.Felhasználók.Controls.Add(this.dataGridViewfelhasznalok);
            this.Felhasználók.Location = new System.Drawing.Point(4, 22);
            this.Felhasználók.Name = "Felhasználók";
            this.Felhasználók.Padding = new System.Windows.Forms.Padding(3);
            this.Felhasználók.Size = new System.Drawing.Size(665, 398);
            this.Felhasználók.TabIndex = 1;
            this.Felhasználók.Text = "Felhasználók";
            this.Felhasználók.UseVisualStyleBackColor = true;
            // 
            // dataGridViewfelhasznalok
            // 
            this.dataGridViewfelhasznalok.BackgroundColor = System.Drawing.Color.Moccasin;
            this.dataGridViewfelhasznalok.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewfelhasznalok.Location = new System.Drawing.Point(-4, 0);
            this.dataGridViewfelhasznalok.Name = "dataGridViewfelhasznalok";
            this.dataGridViewfelhasznalok.Size = new System.Drawing.Size(685, 402);
            this.dataGridViewfelhasznalok.TabIndex = 0;
            // 
            // buttonbetoltes
            // 
            this.buttonbetoltes.Location = new System.Drawing.Point(734, 50);
            this.buttonbetoltes.Name = "buttonbetoltes";
            this.buttonbetoltes.Size = new System.Drawing.Size(115, 38);
            this.buttonbetoltes.TabIndex = 1;
            this.buttonbetoltes.Text = "Adatok betöltése";
            this.buttonbetoltes.UseVisualStyleBackColor = true;
            this.buttonbetoltes.Click += new System.EventHandler(this.buttonbetoltes_Click);
            // 
            // buttonkilepes
            // 
            this.buttonkilepes.Location = new System.Drawing.Point(734, 394);
            this.buttonkilepes.Name = "buttonkilepes";
            this.buttonkilepes.Size = new System.Drawing.Size(115, 38);
            this.buttonkilepes.TabIndex = 2;
            this.buttonkilepes.Text = "Kilépés";
            this.buttonkilepes.UseVisualStyleBackColor = true;
            this.buttonkilepes.Click += new System.EventHandler(this.buttonkilepes_Click);
            // 
            // errorProviderhozzaad
            // 
            this.errorProviderhozzaad.ContainerControl = this;
            // 
            // errorProvidermodositas
            // 
            this.errorProvidermodositas.ContainerControl = this;
            // 
            // buttontorles
            // 
            this.buttontorles.Location = new System.Drawing.Point(733, 182);
            this.buttontorles.Name = "buttontorles";
            this.buttontorles.Size = new System.Drawing.Size(115, 38);
            this.buttontorles.TabIndex = 3;
            this.buttontorles.Text = "Törlés";
            this.buttontorles.UseVisualStyleBackColor = true;
            this.buttontorles.Click += new System.EventHandler(this.buttontorles_Click);
            // 
            // buttonmodositas
            // 
            this.buttonmodositas.Location = new System.Drawing.Point(733, 138);
            this.buttonmodositas.Name = "buttonmodositas";
            this.buttonmodositas.Size = new System.Drawing.Size(115, 38);
            this.buttonmodositas.TabIndex = 4;
            this.buttonmodositas.Text = "Módosítás";
            this.buttonmodositas.UseVisualStyleBackColor = true;
            this.buttonmodositas.Click += new System.EventHandler(this.buttonmodositas_Click);
            // 
            // buttonUj
            // 
            this.buttonUj.Location = new System.Drawing.Point(733, 94);
            this.buttonUj.Name = "buttonUj";
            this.buttonUj.Size = new System.Drawing.Size(115, 38);
            this.buttonUj.TabIndex = 5;
            this.buttonUj.Text = "Hozzáadás";
            this.buttonUj.UseVisualStyleBackColor = true;
            this.buttonUj.Click += new System.EventHandler(this.buttonUj_Click);
            // 
            // comboBoxSzuresAllatkert
            // 
            this.comboBoxSzuresAllatkert.FormattingEnabled = true;
            this.comboBoxSzuresAllatkert.Location = new System.Drawing.Point(733, 290);
            this.comboBoxSzuresAllatkert.Name = "comboBoxSzuresAllatkert";
            this.comboBoxSzuresAllatkert.Size = new System.Drawing.Size(202, 21);
            this.comboBoxSzuresAllatkert.TabIndex = 6;
            this.comboBoxSzuresAllatkert.SelectionChangeCommitted += new System.EventHandler(this.comboBoxSzuresAllatkert_SelectionChangeCommitted);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(733, 264);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Szűrés";
            // 
            // FormKezdo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(948, 481);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxSzuresAllatkert);
            this.Controls.Add(this.buttonUj);
            this.Controls.Add(this.buttonmodositas);
            this.Controls.Add(this.buttontorles);
            this.Controls.Add(this.buttonkilepes);
            this.Controls.Add(this.buttonbetoltes);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormKezdo";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.Állatok.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllatok)).EndInit();
            this.Felhasználók.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewfelhasznalok)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderhozzaad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvidermodositas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Állatok;
        private System.Windows.Forms.TabPage Felhasználók;
        private System.Windows.Forms.DataGridView dataGridViewAllatok;
        private System.Windows.Forms.Button buttonbetoltes;
        private System.Windows.Forms.Button buttonkilepes;
        private System.Windows.Forms.ErrorProvider errorProviderhozzaad;
        private System.Windows.Forms.DataGridView dataGridViewfelhasznalok;
        private System.Windows.Forms.ErrorProvider errorProvidermodositas;
        private System.Windows.Forms.Button buttonUj;
        private System.Windows.Forms.Button buttonmodositas;
        private System.Windows.Forms.Button buttontorles;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxSzuresAllatkert;
    }
}

