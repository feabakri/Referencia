﻿using AllatAdmin.Model;
using ConnectToMysqlDatabase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllatAdmin.Repository
{
    class FelhasznalokRepo
    {
        List<Felhasznalok> felhasznalok;
        public FelhasznalokRepo()
        {
            felhasznalok = new List<Felhasznalok>();
            fillFelhasznaloksListFromDatabase();
        }

        private void fillFelhasznaloksListFromDatabase()
        {
            MySQLDatabase md = new MySQLDatabase();
            MySQLDatabaseInterface mdi = md.getDatabaseInterface();
            mdi.open();
            string query = "SELECT * FROM felhasznalok ";
            DataTable dtCustomer = mdi.getToDataTable(query);
            mdi.close();

            foreach (DataRow row in dtCustomer.Rows)
            {
                int felhasznaloazonosito = Convert.ToInt32(row["azonosito"].ToString());
                string felhasznalonev = row["felhasznalonev"].ToString();
                string jelszo = row["jelszo"].ToString();
                int jogosultsag = Convert.ToInt32(row["jogosultsag"].ToString());
                Felhasznalok f = new Felhasznalok(felhasznaloazonosito, felhasznalonev, jelszo, jogosultsag);
                felhasznalok.Add(f);
            }
        }

        internal void editFelhasznalok(Felhasznalok felhasznalo)
        {
            foreach (Felhasznalok fe in felhasznalok)
            {
                if (fe.getazonosito() == felhasznalo.getazonosito())
                {


                    fe.setfelhasznalonev(felhasznalo.getfelhasznalonev());
                    fe.setjelszo(felhasznalo.getjelszo());
                    fe.setjogosultsag(felhasznalo.getjogosultsag());
                    editFelhInDB(felhasznalo);

                }
            }
        }

        private void editFelhInDB(Felhasznalok felhasznalo)
        {
            MySQLDatabase msd = new MySQLDatabase();
            MySQLDatabaseInterface mdi = msd.getDatabaseInterface();
            string query = felhasznalo.getUpdateQuery();
            mdi.open();
            mdi.executeDMQuery(query);
            mdi.close();
        }

        internal void addFelhasznalo(Felhasznalok felhasznalo)
        {
            felhasznalok.Add(felhasznalo);
            addFelhasznalokToDatabase(felhasznalo);
        }

        private void addFelhasznalokToDatabase(Felhasznalok felhasznalo)
        {
            MySQLDatabase msd = new MySQLDatabase();
            MySQLDatabaseInterface mdi = msd.getDatabaseInterface();
            string query = felhasznalo.getInsertQuery();
            mdi.open();
            mdi.executeDMQuery(query);
            mdi.close();
        }

        internal void delFelh(Felhasznalok felhasznalo)
        {
            int index = 0;
            foreach (Felhasznalok fe in felhasznalok)
            {
                if (fe.getazonosito() == felhasznalo.getazonosito())
                {
                    removefelhdb(fe);
                    felhasznalok.RemoveAt(index);
                    return;
                }
                index++;
            }
        }

        private void removefelhdb(Felhasznalok fe)
        {
            MySQLDatabase msd = new MySQLDatabase();
            MySQLDatabaseInterface mdi = msd.getDatabaseInterface();
            string query = fe.getDeleteQuery();
            mdi.open();
            mdi.executeDMQuery(query);
            mdi.close();
        }

        public DataTable getFelhasznaloksDataTable()
        {
            DataTable cDT = new DataTable();
            cDT.Columns.Add("Azonosito", typeof(int));
            cDT.Columns.Add("Felhasználónév", typeof(string));
            cDT.Columns.Add("Jelszó", typeof(string));
            cDT.Columns.Add("Jogosultság", typeof(int));

            foreach (Felhasznalok f in felhasznalok)
            {
                cDT.Rows.Add(f.getazonosito(), f.getfelhasznalonev(), f.getjelszo(), f.getjogosultsag());
            }
            return cDT;
        }
        public bool checkExist(Felhasznalok felhasznalo)
        {
            foreach (Felhasznalok f in felhasznalok)
            {
                if (f.getazonosito() == felhasznalo.getazonosito())
                    return true;
            }
            return false;
        }

        public int nextID()
        {
            MySQLDatabase ujID = new MySQLDatabase();
            MySQLDatabaseInterface mdujid = ujID.getDatabaseInterface();
            mdujid.open();
            int max;
            bool siker = int.TryParse(mdujid.executeScalarQuery("SELECT MAX(azonosito) FROM felhasznalok"), out max);
            if (!siker)
            {
                MessageBox.Show("Nem lehet megállapítani a következő rekord kulcsát. Adatbázis lekérdezési hiba.", "Hiba...", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            mdujid.close();
            return max + 1;
        }
    }
}
