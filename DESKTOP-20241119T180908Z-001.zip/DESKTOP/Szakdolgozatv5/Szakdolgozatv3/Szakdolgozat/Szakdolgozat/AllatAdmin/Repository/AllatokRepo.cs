﻿using AllatAdmin.Model;
using ConnectToMysqlDatabase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllatAdmin.Repository
{
    class AllatokRepo
    {
        List<Allat> allatok;
        List<string> allatkertek;
        public AllatokRepo()
        {
            allatok = new List<Allat>();
            allatkertek = new List<string>();

        }

        private void fillAllatListfromDatabase()
        {
            MySQLDatabase md = new MySQLDatabase();
            MySQLDatabaseInterface mdi = md.getDatabaseInterface();
            mdi.open();
            string query = "SELECT allatok.Azonosito,allatok.Fajta,allatok.Kor,allatok.Nev,allatok.Darab,allatkert.nev as Allatkert " +
                            "FROM allatok " +
                            "INNER JOIN allatkert ON allatok.allatkert_azonosito = allatkert.id";
            DataTable dtCustomer = mdi.getToDataTable(query);
            mdi.close();

            foreach (DataRow row in dtCustomer.Rows)
            {
                int allatazonosito = Convert.ToInt32(row["Azonosito"].ToString());
                string allatfajta = row["Fajta"].ToString();
                int allatkor = Convert.ToInt32(row["Kor"].ToString());
                string allatnev = row["Nev"].ToString();
                int allatdarab = Convert.ToInt32(row["Darab"].ToString());
                string allatkert = row["Allatkert"].ToString();
                Allat a = new Allat(allatazonosito, allatfajta, allatkor, allatnev, allatdarab, allatkert);
                allatok.Add(a);
            }
        }

        private void fillAllatkertekListFromDb()
        {
            MySQLDatabase md = new MySQLDatabase();
            MySQLDatabaseInterface mdi = md.getDatabaseInterface();
            mdi.open();
            string query = "SELECT nev FROM allatkert";
            DataTable allatkertekDT = mdi.getToDataTable(query);
            mdi.close();
            allatkertek.Add("Összes");
            foreach (DataRow row in allatkertekDT.Rows)
            {
                string allatkert = row["nev"].ToString();
                allatkertek.Add(allatkert);

            }


        }

        public DataTable loadAllatDataSzuressel(string allatkert)
        {
            allatok.Clear();
            fillAllatListfromDatabase();
            allatkertek.Clear();
            fillAllatkertekListFromDb();
            DataTable aDT = new DataTable();
            aDT.Columns.Add("Azonosito", typeof(int));
            aDT.Columns.Add("Fajta", typeof(string));
            aDT.Columns.Add("Kor", typeof(int));
            aDT.Columns.Add("Nev", typeof(string));
            aDT.Columns.Add("Darab", typeof(int));
            aDT.Columns.Add("Allatkert", typeof(string));
            foreach (Allat a in allatok)
            {
                if(a.getAllatkert() == allatkert)
                {
                    aDT.Rows.Add(a.getazonosito(), a.getfajta(), a.getkor(), a.getnev(), a.getdarab(), a.getAllatkert());
                }
            }
            return aDT;
        }

        public List<string> returnAllatkertek()
        {
            return allatkertek;

        }

        public DataTable getAllatokDataTable()
        {
            allatok.Clear();
            allatkertek.Clear();
            fillAllatListfromDatabase();
            fillAllatkertekListFromDb();
            DataTable cDT = new DataTable();
            cDT.Columns.Add("Azonosito", typeof(int));
            cDT.Columns.Add("Fajta", typeof(string));
            cDT.Columns.Add("Kor", typeof(int));
            cDT.Columns.Add("Nev", typeof(string));
            cDT.Columns.Add("Darab", typeof(int));
            cDT.Columns.Add("Allatkert", typeof(string));
            foreach (Allat a in allatok)
            {
                cDT.Rows.Add(a.getazonosito(), a.getfajta(), a.getkor(), a.getnev(), a.getdarab(), a.getAllatkert());
            }
            return cDT;
        }



       

        public bool checkExist(Allat allat)
        {
            foreach (Allat a in allatok)
            {
                if (a.getazonosito() == allat.getazonosito())
                    return true;
            }
            return false;
        }

        public int nextID()
        {
            MySQLDatabase ujID = new MySQLDatabase();
            MySQLDatabaseInterface mdujid = ujID.getDatabaseInterface();
            mdujid.open();
            int max;
            bool siker = int.TryParse(mdujid.executeScalarQuery("SELECT MAX(Azonosito) FROM allatok"), out max);
            if (!siker)
            {
                MessageBox.Show("Nem lehet megállapítani a következő rekord kulcsát. Adatbázis lekérdezési hiba.", "Hiba...", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            mdujid.close();
            return max + 1;
        }

        public void addAllat(Allat allat)
        {
            allatok.Add(allat);
            addAllatokToDatabase(allat);
        }

        private void addAllatokToDatabase(Allat allat)
        {
            MySQLDatabase msd = new MySQLDatabase();
            MySQLDatabaseInterface mdi = msd.getDatabaseInterface();
            string query = allat.getInsertQuery(getAllatkertAzon(allat));
            mdi.open();
            mdi.executeDMQuery(query);
            mdi.close();
        }

        public void editAllat(Allat allat)
        {
            foreach (Allat cu in allatok)
            {
                if (cu.getazonosito() == allat.getazonosito())
                {

                    cu.setnev(allat.getnev());
                    cu.setkor(allat.getkor());
                    cu.setfajta(allat.getfajta());
                    cu.setdarab(allat.getdarab());
                    cu.setAllatkert(allat.getAllatkert());
                    editAllatInDB(allat);

                }
            }
        }

        private void editAllatInDB(Allat allat)
        {
            MySQLDatabase msd = new MySQLDatabase();
            MySQLDatabaseInterface mdi = msd.getDatabaseInterface();
            string query = allat.getUpdateQuery();
            mdi.open();
            mdi.executeDMQuery(query);
            mdi.close();
        }

        public void delAllat(Allat id)
        {
            int index = 0;
            foreach (Allat cu in allatok)
            {
                if (cu.getazonosito() == id.getazonosito())
                {
                    removeAllatDB(cu);
                    allatok.RemoveAt(index);
                    return;
                }
                index++;
            }
        }

        private void removeAllatDB(Allat cu)
        {
            MySQLDatabase msd = new MySQLDatabase();
            MySQLDatabaseInterface mdi = msd.getDatabaseInterface();
            string query = cu.getDeleteQuery();
            mdi.open();
            mdi.executeDMQuery(query);
            mdi.close();
        }

        public int getAllatkertAzon(Allat a)
        {
            MySQLDatabase allatkertAzon = new MySQLDatabase();
            MySQLDatabaseInterface mdallatkerta = allatkertAzon.getDatabaseInterface();
            mdallatkerta.open();
            int allatkerta;
            bool siker = int.TryParse(mdallatkerta.executeScalarQuery("SELECT id FROM allatkert WHERE nev='"+a.getAllatkert()+"'"), out allatkerta);
            if (!siker)
            {
                MessageBox.Show("Nem lehet megállapítani a következő rekord kulcsát. Adatbázis lekérdezési hiba.", "Hiba...", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            mdallatkerta.close();
            return allatkerta;




        }
    }
}
