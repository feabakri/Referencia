﻿using AllatAdmin.Model;
using ConnectToMysqlDatabase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllatAdmin.Repository
{
    class MegrendelesekRepo
    {
        List<Megrendelesek> megrendelesek;
        public MegrendelesekRepo()
        {
            megrendelesek = new List<Megrendelesek>();
            fillMegrendeleseksListFromDatabase();
        }

        private void fillMegrendeleseksListFromDatabase()
        {
            MySQLDatabase md = new MySQLDatabase();
            MySQLDatabaseInterface mdi = md.getDatabaseInterface();
            mdi.open();
            string query = "SELECT * FROM megrendelesek ";
            DataTable dtCustomer = mdi.getToDataTable(query);
            mdi.close();
            foreach (DataRow row in dtCustomer.Rows)
            {
                int azonosito = Convert.ToInt32(row["azonosito"].ToString());
                string tipus = row["tipus"].ToString();
                string allatfajta = row["fajta"].ToString();
                int allatkor = Convert.ToInt32(row["kor"].ToString());
                string allatnev = row["nev"].ToString();
                int allatdarab = Convert.ToInt32(row["darab"].ToString());

                Megrendelesek m = new Megrendelesek(azonosito, tipus, allatfajta, allatkor, allatnev, allatdarab);
                megrendelesek.Add(m);
            }
        }
        public DataTable getMegrendeleseksDataTable()
        {
            DataTable mDT = new DataTable();
            mDT.Columns.Add("Azonosító", typeof(int));
            mDT.Columns.Add("Típus", typeof(string));
            mDT.Columns.Add("Fajta", typeof(string));
            mDT.Columns.Add("Kor", typeof(int));
            mDT.Columns.Add("Név", typeof(string));
            mDT.Columns.Add("Darab", typeof(int));
            foreach (Megrendelesek m in megrendelesek)
            {
                mDT.Rows.Add(m.getazonosito(), m.getipus(), m.getfajta(), m.getkor(), m.getnev(), m.getdarab());
            }
            return mDT;
        }
        public bool checkExist(Megrendelesek megrendeles)
        {
            foreach (Megrendelesek m in megrendelesek)
            {
                if (m.getazonosito() == megrendeles.getazonosito())
                    return true;
            }
            return false;
        }
        public int nextID()
        {
            MySQLDatabase ujID = new MySQLDatabase();
            MySQLDatabaseInterface mdujid = ujID.getDatabaseInterface();
            mdujid.open();
            int max;
            bool siker = int.TryParse(mdujid.executeScalarQuery("SELECT MAX(azonosito) FROM megrendelesek"), out max);
            if (!siker)
            {
                MessageBox.Show("Nem lehet megállapítani a következő rekord kulcsát. Adatbázis lekérdezési hiba.", "Hiba...", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            mdujid.close();
            return max + 1;
        }
        public void addMegrendeles(Megrendelesek megrendeles)
        {
            megrendelesek.Add(megrendeles);
            addMegrendelesekToDatabase(megrendeles);
        }

        private void addMegrendelesekToDatabase(Megrendelesek megrendeles)
        {
            MySQLDatabase msd = new MySQLDatabase();
            MySQLDatabaseInterface mdi = msd.getDatabaseInterface();
            string query = megrendeles.getInsertQuery();
            mdi.open();
            mdi.executeDMQuery(query);
            mdi.close();
        }
        public void editMegrendelesek(Megrendelesek megrendeles)
        {
            foreach (Megrendelesek me in megrendelesek)
            {
                if (me.getazonosito() == megrendeles.getazonosito())
                {
                    me.settipus(megrendeles.getipus());
                    me.setnev(megrendeles.getnev());
                    me.setkor(megrendeles.getkor());
                    me.setfajta(megrendeles.getfajta());
                    me.setdarab(megrendeles.getdarab());
                    editMegrInDB(megrendeles);
                }
            }
        }

        private void editMegrInDB(Megrendelesek megrendeles)
        {
            MySQLDatabase msd = new MySQLDatabase();
            MySQLDatabaseInterface mdi = msd.getDatabaseInterface();
            string query = megrendeles.getUpdateQuery();
            mdi.open();
            mdi.executeDMQuery(query);
            mdi.close();
        }
        public void delMegr(Megrendelesek megrendeles)
        {
            int index = 0;
            foreach (Megrendelesek me in megrendelesek)
            {
                if (me.getazonosito() == megrendeles.getazonosito())
                {
                    removeMegrhdb(me);
                    megrendelesek.RemoveAt(index);
                    return;
                }
                index++;
            }
        }

        private void removeMegrhdb(Megrendelesek me)
        {
            MySQLDatabase msd = new MySQLDatabase();
            MySQLDatabaseInterface mdi = msd.getDatabaseInterface();
            string query = me.getDeleteQuery();
            mdi.open();
            mdi.executeDMQuery(query);
            mdi.close();
        }
    }
}
