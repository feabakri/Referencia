﻿using AllatAdmin.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllatAdmin
{
    public partial class FelhUjEdit : Form
    {
        private Felhasznalok f;
        public FelhUjEdit(Felhasznalok f)
        {
            InitializeComponent();
            this.f = f;
            showData();
        }

        private void showData()
        {
            textBoxfelhasznalonev.Text = f.getfelhasznalonev();
            textBoxjelszo.Text = f.getjelszo();
            textBoxjogosultsag.Text = f.getjogosultsag().ToString();
        }
        public Felhasznalok UjEditFelh()
        {
            return f;
        }

        private void buttonrendben_Click(object sender, EventArgs e)
        {
            f.setfelhasznalonev(textBoxfelhasznalonev.Text);
            f.setjelszo(textBoxjelszo.Text);
            f.setjogosultsag(Convert.ToInt32(textBoxjogosultsag.Text));
        }
    }
}
