﻿using AllatAdmin.Model;
using AllatAdmin.MyException;
using AllatAdmin.Service;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllatAdmin
{
    public partial class FormKezdo : Form
    {
        AllatService asc;
        FelhasznalokService fsc;
        MegrendelesekService msc;
        
        public FormKezdo()
        {
            asc = new AllatService();
            fsc = new FelhasznalokService();
            msc = new MegrendelesekService();
            InitializeComponent();
            dataGridViewAllatok.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridViewAllatok.AllowUserToAddRows = false;
            dataGridViewAllatok.ClearSelection();
            dataGridViewAllatok.SelectionMode= DataGridViewSelectionMode.FullRowSelect;
            dataGridViewfelhasznalok.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridViewfelhasznalok.AllowUserToAddRows = false;
            dataGridViewfelhasznalok.ClearSelection();
            dataGridViewfelhasznalok.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

        }

        private void buttonbetoltes_Click(object sender, EventArgs e)
        {
            if (dataGridViewAllatok.DataSource != null)
            {
                dataGridViewAllatok.DataSource = null;
            }
            dataGridViewAllatok.DataSource = asc.loadAllatData();
            comboBoxSzuresAllatkert.DataSource = asc.fillAllatkertSzures();

            if (dataGridViewfelhasznalok.DataSource != null)
            {
                dataGridViewfelhasznalok.DataSource = null;
            }
            dataGridViewfelhasznalok.DataSource = fsc.LoadFelhData();
        



        }

        private void buttonkilepes_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonUj_Click(object sender, EventArgs e)
        {
            try
            {
                if (tabControl1.SelectedTab.Text == "Állatok")
                {
                    int id = asc.nextID();
                    Allat ujallat = new Allat(id);
                    AllatUjEdit fne = new AllatUjEdit(ujallat, asc.fillAllatkertSzures());
                    if (fne.ShowDialog(this) == DialogResult.OK)
                    {
                        Allat newallat = fne.AddAllat();
                        asc.addAllat(newallat);
                    }
                    dataGridViewAllatok.DataSource = null;
                    dataGridViewAllatok.DataSource = asc.loadAllatData();
                }
                else if (tabControl1.SelectedTab.Text == "Felhasználók")
                {

                    int id = fsc.nextID();
                    Felhasznalok ujfelh = new Felhasznalok(id);
                    FelhUjEdit uff = new FelhUjEdit(ujfelh);
                    if (uff.ShowDialog(this) == DialogResult.OK)
                    {
                        Felhasznalok newfelh = uff.UjEditFelh();
                        fsc.addFelh(newfelh);
                    }
                    dataGridViewfelhasznalok.DataSource = null;
                    dataGridViewfelhasznalok.DataSource = fsc.LoadFelhData();

                }
                else
                    MessageBox.Show("Válasszon tabot");
            }
            catch (Exception h)
            {

                MessageBox.Show(h.Message);
             
            }
        }

        private void buttonmodositas_Click(object sender, EventArgs e)
        {
            try
            {
                if (tabControl1.SelectedTab.Text == "Állatok")
                {
                    int id = Convert.ToInt32(dataGridViewAllatok.SelectedRows[0].Cells["Azonosito"].Value);
                    Allat ng = new Allat(id,
                        dataGridViewAllatok.SelectedRows[0].Cells["Fajta"].Value.ToString(),
                        Convert.ToInt32(dataGridViewAllatok.SelectedRows[0].Cells["Kor"].Value),
                        dataGridViewAllatok.SelectedRows[0].Cells["Nev"].Value.ToString(),
                        Convert.ToInt32(dataGridViewAllatok.SelectedRows[0].Cells["Darab"].Value),
                        dataGridViewAllatok.SelectedRows[0].Cells["Allatkert"].Value.ToString());
                    List<string> allatkertek = asc.fillAllatkertSzures();
                    AllatUjEdit fne = new AllatUjEdit(ng,allatkertek);
                    if (fne.ShowDialog(this) == DialogResult.OK)
                    {
                        Allat editedG = fne.AddAllat();
                        asc.editAllat(editedG);
                    }
                    dataGridViewAllatok.DataSource = null;
                    dataGridViewAllatok.DataSource = asc.loadAllatData();
                }
                else if (tabControl1.SelectedTab.Text == "Felhasználók")
                {

                    int id = Convert.ToInt32(dataGridViewfelhasznalok.SelectedRows[0].Cells["Azonosito"].Value);
                    Felhasznalok fs = new Felhasznalok(id, dataGridViewfelhasznalok.SelectedRows[0].Cells["Felhasználónév"].Value.ToString()
                        , dataGridViewfelhasznalok.SelectedRows[0].Cells["Jelszó"].Value.ToString(),
                        Convert.ToInt32(dataGridViewfelhasznalok.SelectedRows[0].Cells["Jogosultság"].Value));
                    FelhUjEdit uff = new FelhUjEdit(fs);
                    if (uff.ShowDialog(this) == DialogResult.OK)
                    {
                        Felhasznalok editedFelh = uff.UjEditFelh();
                        fsc.editFelh(editedFelh);
                    }
                    dataGridViewfelhasznalok.DataSource = null;
                    dataGridViewfelhasznalok.DataSource = fsc.LoadFelhData();

                }
                else
                    MessageBox.Show("Válasszon tabot");
            }
            catch (AllatServiceException alc)
            {
                errorProvidermodositas.SetError(buttonmodositas, alc.Message);
            }
        }


        private void comboBoxSzuresAllatkert_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                string allatkert = comboBoxSzuresAllatkert.SelectedItem.ToString();
                if (allatkert == "Összes")
                {

                    dataGridViewAllatok.DataSource = null;
                    dataGridViewAllatok.DataSource = asc.loadAllatData();
                }
                else
                {

                    dataGridViewAllatok.DataSource = null;
                    dataGridViewAllatok.DataSource = asc.loadAllatDataSzuressel(allatkert);

                }
                dataGridViewAllatok.ClearSelection();
            }
            catch (Exception)
            {



            }
                
        }

        private void buttontorles_Click(object sender, EventArgs e)
        {
            try
            {
                if (tabControl1.SelectedTab.Text == "Állatok")
                {
                    
                    int id = Convert.ToInt32(dataGridViewAllatok.SelectedRows[0].Cells["Azonosito"].Value);
                    Allat ng = new Allat(id,
                        dataGridViewAllatok.SelectedRows[0].Cells["Fajta"].Value.ToString(),
                        Convert.ToInt32(dataGridViewAllatok.SelectedRows[0].Cells["Kor"].Value),
                        dataGridViewAllatok.SelectedRows[0].Cells["Nev"].Value.ToString(),
                        Convert.ToInt32(dataGridViewAllatok.SelectedRows[0].Cells["Darab"].Value),
                        dataGridViewAllatok.SelectedRows[0].Cells["Allatkert"].Value.ToString());
                    asc.deleteAllat(ng);
                    dataGridViewAllatok.DataSource = null;
                    dataGridViewAllatok.DataSource = asc.loadAllatData();
                   
                }
                else if (tabControl1.SelectedTab.Text == "Felhasználók")
                {

                    int id = Convert.ToInt32(dataGridViewfelhasznalok.SelectedRows[0].Cells["Azonosito"].Value);
                    Felhasznalok fs = new Felhasznalok(id,
                         dataGridViewfelhasznalok.SelectedRows[0].Cells["Felhasználónév"].Value.ToString(),
                         dataGridViewfelhasznalok.SelectedRows[0].Cells["Jelszó"].Value.ToString(),
                        Convert.ToInt32(dataGridViewfelhasznalok.SelectedRows[0].Cells["Jogosultság"].Value));
                    fsc.deleteFelh(fs);
                    dataGridViewfelhasznalok.DataSource = null;
                    dataGridViewfelhasznalok.DataSource = fsc.LoadFelhData();
                }
                else
                    MessageBox.Show("Válasszon tabot");
            }
            catch (AllatServiceException alc)
            {
                errorProvidermodositas.SetError(buttonmodositas, alc.Message);
            }




        }
    }
}
