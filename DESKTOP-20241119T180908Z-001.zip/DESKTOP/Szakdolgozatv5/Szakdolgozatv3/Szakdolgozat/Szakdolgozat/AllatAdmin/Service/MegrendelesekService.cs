﻿using AllatAdmin.Model;
using AllatAdmin.MyException;
using AllatAdmin.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatAdmin.Service
{
    class MegrendelesekService
    {
        MegrendelesekRepo mr;

        public MegrendelesekService()
        {
            mr = new MegrendelesekRepo();
        }

        public DataTable LoadMegrendelesData()
        {
            return mr.getMegrendeleseksDataTable();
        }
        public void addMegrendeles(Megrendelesek megrendeles)
        {
            if (mr.checkExist(megrendeles))
                throw new MegrendelesekServiceException(
                    megrendeles.getazonosito() + " megrendelés már létezik."
                );
            mr.addMegrendeles(megrendeles);
        }


        public void deleteMegrendeles(Megrendelesek megrendeles)
        {
            if (!mr.checkExist(megrendeles))
            {
                throw new MegrendelesekServiceException(megrendeles.getazonosito() + " nincs ilyen azonosítójú megrendelés");
            }
            else
            {
                mr.delMegr(megrendeles);
            }

        }

        internal int nextID()
        {
            return mr.nextID();
        }
    }
}
