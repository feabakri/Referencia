﻿using AllatAdmin.Model;
using AllatAdmin.MyException;
using AllatAdmin.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatAdmin.Service
{
    class FelhasznalokService
    {
        FelhasznalokRepo fr;
        public FelhasznalokService()
        {
            fr = new FelhasznalokRepo();
        }

        public DataTable LoadFelhData()
        {
            return fr.getFelhasznaloksDataTable();
        }
        public void addFelh(Felhasznalok felhasznalo)
        {
            if (fr.checkExist(felhasznalo))
                throw new FelhasznalokServiceException(
                    felhasznalo.getfelhasznalonev() + " A felhasználó már létezik."
                );
            fr.addFelhasznalo(felhasznalo);
        }
        public void editFelh(Felhasznalok felhasznalo)
        {
            if (!fr.checkExist(felhasznalo))
            {
                throw new FelhasznalokServiceException(felhasznalo.getazonosito() + " nincs ilyen azonosítójú felhasználó");
            }
            else
            {
                fr.editFelhasznalok(felhasznalo);
            }
        }

        public void deleteFelh(Felhasznalok felhasznalo)
        {
            if (!fr.checkExist(felhasznalo))
            {
                throw new FelhasznalokServiceException(felhasznalo.getazonosito() + " nincs ilyen azonosítójú felhasználó");
            }
            else
            {
                fr.delFelh(felhasznalo);
            }

        }

        internal int nextID()
        {
            return fr.nextID();
        }
    }
}
