﻿using AllatAdmin.Model;
using AllatAdmin.MyException;
using AllatAdmin.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatAdmin.Service
{
    class AllatService
    {
        AllatokRepo ar;

        public AllatService()
        {
            ar = new AllatokRepo();
        }

        public DataTable loadAllatData()
        {
            return ar.getAllatokDataTable();
        }

        public void addAllat(Allat allat)
        {
            if (ar.checkExist(allat))
                throw new AllatServiceException(allat.getnev() + " állat már létezik.");
            ar.addAllat(allat);
        }
        public void editAllat(Allat allat)
        {
            if (!ar.checkExist(allat))
            {
                throw new AllatServiceException(allat.getazonosito() + " nincs ilyen azonosítójú állat");
            }
            else
            {
                ar.editAllat(allat);
            }
        }

        public void deleteAllat(Allat allat)
        {
            if (!ar.checkExist(allat))
            {
                throw new AllatServiceException(allat.getazonosito() + " nincs ilyen azonosítójú állat");
            }
            else
            {
                ar.delAllat(allat);
            }

        }

        internal int nextID()
        {
            return ar.nextID();
        }

        public List<string>  fillAllatkertSzures()
        {
            return ar.returnAllatkertek();
        }

        public DataTable loadAllatDataSzuressel(string allatkert)
        {
            return ar.loadAllatDataSzuressel(allatkert);
        }
    }
}
