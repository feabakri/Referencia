﻿namespace AllatAdmin
{
    partial class FelhUjEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxfelhasznalonev = new System.Windows.Forms.TextBox();
            this.textBoxjogosultsag = new System.Windows.Forms.TextBox();
            this.textBoxjelszo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonrendben = new System.Windows.Forms.Button();
            this.buttonmegse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxfelhasznalonev
            // 
            this.textBoxfelhasznalonev.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxfelhasznalonev.Location = new System.Drawing.Point(278, 92);
            this.textBoxfelhasznalonev.Name = "textBoxfelhasznalonev";
            this.textBoxfelhasznalonev.Size = new System.Drawing.Size(136, 20);
            this.textBoxfelhasznalonev.TabIndex = 0;
            // 
            // textBoxjogosultsag
            // 
            this.textBoxjogosultsag.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxjogosultsag.Location = new System.Drawing.Point(278, 180);
            this.textBoxjogosultsag.Name = "textBoxjogosultsag";
            this.textBoxjogosultsag.Size = new System.Drawing.Size(136, 20);
            this.textBoxjogosultsag.TabIndex = 1;
            // 
            // textBoxjelszo
            // 
            this.textBoxjelszo.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxjelszo.Location = new System.Drawing.Point(278, 137);
            this.textBoxjelszo.Name = "textBoxjelszo";
            this.textBoxjelszo.Size = new System.Drawing.Size(136, 20);
            this.textBoxjelszo.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(88, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Felhasználónév";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(88, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Jogosultság";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(88, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Jelszó";
            // 
            // buttonrendben
            // 
            this.buttonrendben.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonrendben.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonrendben.Location = new System.Drawing.Point(181, 270);
            this.buttonrendben.Name = "buttonrendben";
            this.buttonrendben.Size = new System.Drawing.Size(109, 40);
            this.buttonrendben.TabIndex = 6;
            this.buttonrendben.Text = "Rendben";
            this.buttonrendben.UseVisualStyleBackColor = true;
            this.buttonrendben.Click += new System.EventHandler(this.buttonrendben_Click);
            // 
            // buttonmegse
            // 
            this.buttonmegse.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonmegse.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonmegse.Location = new System.Drawing.Point(346, 270);
            this.buttonmegse.Name = "buttonmegse";
            this.buttonmegse.Size = new System.Drawing.Size(109, 40);
            this.buttonmegse.TabIndex = 8;
            this.buttonmegse.Text = "Mégse";
            this.buttonmegse.UseVisualStyleBackColor = true;
            // 
            // FelhUjEdit
            // 
            this.AcceptButton = this.buttonrendben;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.CancelButton = this.buttonmegse;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonmegse);
            this.Controls.Add(this.buttonrendben);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxjelszo);
            this.Controls.Add(this.textBoxjogosultsag);
            this.Controls.Add(this.textBoxfelhasznalonev);
            this.Name = "FelhUjEdit";
            this.Text = "FelhUjEdit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxfelhasznalonev;
        private System.Windows.Forms.TextBox textBoxjogosultsag;
        private System.Windows.Forms.TextBox textBoxjelszo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonrendben;
        private System.Windows.Forms.Button buttonmegse;
    }
}