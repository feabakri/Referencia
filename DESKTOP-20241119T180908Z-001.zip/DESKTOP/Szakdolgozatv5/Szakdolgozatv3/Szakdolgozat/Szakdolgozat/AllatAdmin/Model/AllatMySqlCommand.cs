﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatAdmin.Model
{
    public partial class Allat
    {
        public string getUpdateQuery()
        {
            string updateQuery = "UPDATE allatok SET Fajta='" + fajta + "'," +
                "Kor=" + kor + ", " +
                "Nev='" + nev + "', " +
                "Darab=" + darab + ", " +
                "allatkert_azonosito=" +
                "(SELECT allatkert.id FROM allatkert " +
                "WHERE allatkert.nev='" + allatkert + "') " +
                "WHERE allatok.Azonosito="+azonosito;
            return updateQuery;


        }

        public string getInsertQuery(int allatkertAzon)
        {
            string queryInsert = "INSERT INTO allatok (Azonosito, Fajta, Kor,Nev,Darab,allatkert_azonosito) VALUES" +
                   "(NULL, '" + this.getfajta() + "', " + this.getkor() + ",'" + this.getnev() + "'," + this.getdarab() + "," + allatkertAzon + ")";

            return queryInsert;
        }


        public string getDeleteQuery()
        {
            string queryDelete = "DELETE FROM `allatok` WHERE Azonosito= " +this.getazonosito() + ";";
            return queryDelete;
        }



    }
}
