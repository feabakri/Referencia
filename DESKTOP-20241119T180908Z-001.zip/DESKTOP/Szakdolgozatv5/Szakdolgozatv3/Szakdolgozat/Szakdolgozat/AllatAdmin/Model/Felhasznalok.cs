﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllatAdmin.Model
{
   public class Felhasznalok
    {
        private int azonosito;
        private string felhasznalonev;
        private string jelszo;
        private int jogosultsag;

        public Felhasznalok(int azonosito, string felhasznalonev, string jelszo, int jogosultsag)
        {
            this.azonosito = azonosito;
            this.felhasznalonev = felhasznalonev;
            this.jelszo = jelszo;
            this.jogosultsag = jogosultsag;

        }
        public Felhasznalok(int azonosito)
        {
            this.azonosito = azonosito;

        }

        public void setazonosito(int azonosito)
        {
            this.azonosito = azonosito;
        }


        public void setfelhasznalonev(string felhasznalonev)
        {
            this.felhasznalonev = felhasznalonev;
        }
        public void setjelszo(string jelszo)
        {
            this.jelszo = jelszo;
        }
        public void setjogosultsag(int jogosultsag)
        {
            this.jogosultsag = jogosultsag;
        }
        public int getazonosito()
        {
            return azonosito;
        }
        public int getjogosultsag()
        {
            return jogosultsag;
        }
        public string getfelhasznalonev()
        {
            return felhasznalonev;
        }
        public string getjelszo()
        {
            return jelszo;
        }
        public override string ToString()
        {
            return azonosito + " " + felhasznalonev + " " + jelszo + "" + jogosultsag;
        }

        public string getUpdateQuery()
        {
            string queryUpdate = "UPDATE `felhasznalok` SET felhasznalonev = '" + getfelhasznalonev() + "', " +
               "jelszo = '" + getjelszo() + "', " +
               "jogosultsag=" + getjogosultsag() + " " +
               "WHERE azonosito = " + getazonosito() + " ;";
            return queryUpdate;
        }

        public string getInsertQuery()
        {
            string queryInsert = "INSERT INTO felhasznalok (azonosito, felhasznalonev, jelszo,jogosultsag) VALUES" +
                     "(NULL, '" + this.getfelhasznalonev() + "','" + this.getjelszo() + "'," + this.getjogosultsag() + ")";
            return queryInsert;
        }

        public string getDeleteQuery()
        {
            string queryDelete = "DELETE FROM `felhasznalok` WHERE azonosito= " + getazonosito() + ";";
            return queryDelete;
        }
    }
}
