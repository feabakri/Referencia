﻿using AllatAdmin.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AllatAdmin.Service;

namespace AllatAdmin
{
    public partial class AllatUjEdit : Form
    {
        private Allat a;
        public AllatUjEdit(Allat a, List<string> allatkertek)
        {
            InitializeComponent();
            this.a = a;
            allatkertek.RemoveAt(0);
            comboBoxAllatkert.DataSource = null;
            comboBoxAllatkert.DataSource = allatkertek;
            showData();          
        }

        private void showData()
        {
            if (a.getfajta() != null)
            {
                textBoxfajta.Text = a.getfajta();
                textBoxkor.Text = a.getkor().ToString();
                textBoxnev.Text = a.getnev();
                textBoxdarab.Text = a.getdarab().ToString();
                comboBoxAllatkert.Text = a.getAllatkert().ToString();
            }
        }

        public Allat AddAllat()
        {
            return a;
        }

        private void buttonrendben_Click(object sender, EventArgs e)
        {
            a.setnev(textBoxnev.Text);
            a.setfajta(textBoxfajta.Text);
            a.setkor(Convert.ToInt32(textBoxkor.Text));
            a.setdarab(Convert.ToInt32(textBoxdarab.Text));
            a.setAllatkert(comboBoxAllatkert.SelectedItem.ToString());
        }

        
    }
}
