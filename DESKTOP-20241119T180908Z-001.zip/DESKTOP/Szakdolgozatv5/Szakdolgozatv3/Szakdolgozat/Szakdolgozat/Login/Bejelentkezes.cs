﻿using Login.Model;
using Login.Service;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class Bejelentkezes : Form
    {
        FelhService fs;
        public Bejelentkezes()
        {
            InitializeComponent();
            fs = new FelhService();
        }

        private void buttonkilepes_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonbejelentkezes_Click(object sender, EventArgs e)
        {
            try
            {
                FelhLogin fl = fs.EllenorizFelhListaban(textBoxfelhasznalonev.Text, textBoxjelszo.Text);
                if (fl.getJogosultsag() == 1)
                {
                    this.Hide();
                    AllatAdmin.FormKezdo am = new AllatAdmin.FormKezdo();
                    am.Closed += (s, args) => this.Close();
                    am.Show();
                }
                else
                {
                    this.Hide();
                    AllatUser.FormUser user = new AllatUser.FormUser();
                    user.Closed += (s, args) => this.Close();
                    user.Show();
                }
                errorProviderbejelentkezes.Clear();
                textBoxfelhasznalonev.Clear();
                textBoxjelszo.Clear();
            }
            catch (Exception oe)
            {
                errorProviderbejelentkezes.SetError(buttonbejelentkezes, oe.Message);
            }
        }
    }
}
