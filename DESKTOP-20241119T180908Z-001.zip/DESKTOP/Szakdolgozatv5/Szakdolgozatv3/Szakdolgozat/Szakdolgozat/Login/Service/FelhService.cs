﻿using Login.Model;
using Login.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.Service
{
    class FelhService
    {
        FelhRepo fr;
        public FelhService()
        {
            fr = new FelhRepo();
        }
        public FelhLogin EllenorizFelhListaban(string felhasznalonev, string jelszo)
        {
            return fr.EllenorizFelhListaban(felhasznalonev, jelszo);
        }
    }
}
