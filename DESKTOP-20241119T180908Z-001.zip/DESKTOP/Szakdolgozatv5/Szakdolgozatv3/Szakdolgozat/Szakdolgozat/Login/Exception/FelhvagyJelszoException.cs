﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.MyException
{
    class FelhvagyJelszoException:Exception
    {
        public FelhvagyJelszoException(string message)
           : base(message)
        {

        }
    }
}
