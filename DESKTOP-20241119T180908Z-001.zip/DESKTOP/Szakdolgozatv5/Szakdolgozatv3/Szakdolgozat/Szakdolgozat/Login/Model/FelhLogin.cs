﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.Model
{
    class FelhLogin
    {
        private int azonosito;
        private string felhasznalonev;
        private string jelszo;
        private int jogosultsag;

        public FelhLogin(int azonosito, string felhasznalonev, string jelszo, int jogosultsag)
        {
            this.azonosito = azonosito;
            this.felhasznalonev = felhasznalonev;
            this.jelszo = jelszo;
            this.jogosultsag = jogosultsag;
        }
        public int getazonosito()
        {
            return azonosito;
        }
        public string getfelhasznalonev()
        {
            return felhasznalonev;
        }
        public string getjelszo()
        {
            return jelszo;
        }
        public int getJogosultsag()
        {
            return jogosultsag;

        }
    }
}
