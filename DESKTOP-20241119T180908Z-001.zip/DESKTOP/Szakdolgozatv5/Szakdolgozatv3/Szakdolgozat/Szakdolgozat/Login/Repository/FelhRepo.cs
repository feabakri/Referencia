﻿using ConnectToMysqlDatabase;
using Login.Model;
using Login.MyException;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login.Repository
{
    class FelhRepo
    {
        List<FelhLogin> felhasznalok;
        public FelhRepo()
        {
            felhasznalok = new List<FelhLogin>();
        }
        private void feltoltFelhListaba()
        {
            MySQLDatabase md = new MySQLDatabase();
            MySQLDatabaseInterface mdi = md.getDatabaseInterface();
            mdi.open();
            string query = "SELECT azonosito,felhasznalonev,jelszo,jogosultsag FROM felhasznalok ";
            DataTable dtFelh = mdi.getToDataTable(query);
            mdi.close();

            foreach (DataRow row in dtFelh.Rows)
            {
                int felhazonosito = Convert.ToInt32(row["azonosito"].ToString());
                string felhasznalonev = row["felhasznalonev"].ToString();
                string jelszo = row["jelszo"].ToString();
                int jogosultsag = Convert.ToInt32(row["jogosultsag"]);
                FelhLogin FL = new FelhLogin(felhazonosito, felhasznalonev, jelszo, jogosultsag);
                felhasznalok.Add(FL);
            }

        }
        public FelhLogin EllenorizFelhListaban(string felhasznalonev, string jelszo)
        {
            feltoltFelhListaba();
            if (felhasznalok.Count > 0)
            {
                foreach (FelhLogin fl in felhasznalok)
                {
                    if (fl.getfelhasznalonev() == felhasznalonev && fl.getjelszo() == jelszo)
                        return fl;
                }
                throw new FelhvagyJelszoException("Rossz felhasználónév vagy jelszó");
            }
            else
                throw new Exception("Sikertelen adatbázis kapcsolódás");
        }
    }
}
