﻿namespace Login
{
    partial class Bejelentkezes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBoxfelhasznalonev = new System.Windows.Forms.TextBox();
            this.textBoxjelszo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonbejelentkezes = new System.Windows.Forms.Button();
            this.buttonkilepes = new System.Windows.Forms.Button();
            this.errorProviderbejelentkezes = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderbejelentkezes)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxfelhasznalonev
            // 
            this.textBoxfelhasznalonev.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxfelhasznalonev.Location = new System.Drawing.Point(320, 193);
            this.textBoxfelhasznalonev.Name = "textBoxfelhasznalonev";
            this.textBoxfelhasznalonev.Size = new System.Drawing.Size(212, 20);
            this.textBoxfelhasznalonev.TabIndex = 0;
            // 
            // textBoxjelszo
            // 
            this.textBoxjelszo.BackColor = System.Drawing.Color.Moccasin;
            this.textBoxjelszo.Location = new System.Drawing.Point(320, 258);
            this.textBoxjelszo.Name = "textBoxjelszo";
            this.textBoxjelszo.Size = new System.Drawing.Size(212, 20);
            this.textBoxjelszo.TabIndex = 1;
            this.textBoxjelszo.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(150, 193);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Felhasználónév";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(150, 253);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Jelszó";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(277, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(212, 37);
            this.label3.TabIndex = 4;
            this.label3.Text = "Bejelentkezés";
            // 
            // buttonbejelentkezes
            // 
            this.buttonbejelentkezes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonbejelentkezes.Location = new System.Drawing.Point(349, 325);
            this.buttonbejelentkezes.Name = "buttonbejelentkezes";
            this.buttonbejelentkezes.Size = new System.Drawing.Size(162, 45);
            this.buttonbejelentkezes.TabIndex = 5;
            this.buttonbejelentkezes.Text = "Bejelentkezés";
            this.buttonbejelentkezes.UseVisualStyleBackColor = true;
            this.buttonbejelentkezes.Click += new System.EventHandler(this.buttonbejelentkezes_Click);
            // 
            // buttonkilepes
            // 
            this.buttonkilepes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonkilepes.Location = new System.Drawing.Point(653, 384);
            this.buttonkilepes.Name = "buttonkilepes";
            this.buttonkilepes.Size = new System.Drawing.Size(113, 54);
            this.buttonkilepes.TabIndex = 6;
            this.buttonkilepes.Text = "Kilépés";
            this.buttonkilepes.UseVisualStyleBackColor = true;
            this.buttonkilepes.Click += new System.EventHandler(this.buttonkilepes_Click);
            // 
            // errorProviderbejelentkezes
            // 
            this.errorProviderbejelentkezes.ContainerControl = this;
            // 
            // Bejelentkezes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonkilepes);
            this.Controls.Add(this.buttonbejelentkezes);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxjelszo);
            this.Controls.Add(this.textBoxfelhasznalonev);
            this.Name = "Bejelentkezes";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderbejelentkezes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxfelhasznalonev;
        private System.Windows.Forms.TextBox textBoxjelszo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonbejelentkezes;
        private System.Windows.Forms.Button buttonkilepes;
        private System.Windows.Forms.ErrorProvider errorProviderbejelentkezes;
    }
}

