<?php
require_once 'config/connect.php';
require_once 'config/functions.php';



menu()
?>

    <main role="main">
      <!-- Content -->
      <article>
        <header class="section background-primary text-center">
          <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1">Képek és leírások az állatokról</h1>

        </header>
        <div class="section background-white"> 
          <div class="line">
            <div class="margin">
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
					  <p> Nemének tudományos neve, az Acinonyx</p>
                      <p> Testhossza 110–150 cm</p>
                      <p> Súlya 21–72 kg</p>
                      <p> Élőhelye: Afrika</p>
                      
					  
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-01.jpg" alt="" title="Portfolio Image 1" />
                </div>	
              </div>
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                     <p> Nemének tudományos neve, a Hippotigris</p>
                      <p> Testhossza 110–150 cm</p>
                      <p> Súlya 21–72 kg</p>
                      <p> Élőhelye: Afrika</p> 
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-02.jpg" alt="" title="Portfolio Image 2" />
                </div>	
              </div>
			  
			  
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                       <p> Nemének tudományos neve, a Sphenisciformes</p>
                      <p> Testhossza 40-115 cm</p>
                      <p> Súlya 21 kg</p>
                      <p> Élőhelye: Antarktisz</p> 
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-03.jpg" alt="" title="Portfolio Image 3" />
                </div>	
              </div>
			  
			  
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                     <p> Nemének tudományos neve, a Lycaon pictus</p>
                      <p> Testhossza 92 cm</p>
                      <p> Súlya 22 kg</p>
                      <p> Élőhelye: Afrika</p>  
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-04.jpg" alt="" title="Portfolio Image 4" />
                </div>	
              </div>
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                      <p> Nemének tudományos neve, az Elephantidae</p>
                      <p> Magassága 2,7-3,3 m</p>
                      <p> Súlya 2700-6000 kg</p>
                      <p> Élőhelye: Afrika,Ázsia</p>
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-05.jpg" alt="" title="Portfolio Image 5" />
                </div>	
              </div>
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                      <p> Nemének tudományos neve, a Panthera pardus</p>
                      <p> Testhossza 60–70 cm</p>
                      <p> Súlya 23–27 kg</p>
                      <p> Élőhelye: Afrika,Ázsia</p>  
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-06.jpg" alt="" title="Portfolio Image 6" />
                </div>	
              </div>
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                      <p> Nemének tudományos neve, a Crocodylia</p>
                      <p> Testhossza 4,3–5,2 m</p>
                      <p> Súlya 400-1000 kg</p>
                      <p> Élőhelye: Afrika,Ázsia,Közép-Amerika,Dél-Amerika</p>  
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-07.jpg" alt="" title="Portfolio Image 7" />
                </div>	
              </div>
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                     <p> Nemének tudományos neve, a Ciconia ciconia</p>
                      <p> Testhossza 100-110 cm</p>
                      <p> Súlya 3,4 kg</p>
                      <p> Élőhelye: Európa,Afrika</p>  
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-08.jpg" alt="" title="Portfolio Image 8" />
                </div>	
              </div>
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                     <p> Nemének tudományos neve, a Panthera leo) </p>
                      <p> Testhossza 140-250 cm</p>
                      <p> Súlya 130-190 kg</p>
                      <p> Élőhelye: Afrika</p>  
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-09.jpg" alt="" title="Portfolio Image 9" />
                </div>	
              </div>
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                      <p> Nemének tudományos neve, a Giraffa camelopardalis</p>
                      <p> Testhossza 4,6-6,1 m</p>
                      <p> Súlya 800 kg</p>
                      <p> Élőhelye: Afrika</p>  
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-10.jpg" alt="" title="Portfolio Image 10" />
                </div>	
              </div>
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                      <p> Nemének tudományos neve, az Ursus arctos</p>
                      <p> Magasság 70-150 cm</p>
                      <p> Súlya 80-600 kg</p>
                      <p> Élőhelye: Eurázsia,Alaszka</p>  
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-11.jpg" alt="" title="Portfolio Image 11" />
                </div>	
              </div>
			   <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                      <p> Nemének tudományos neve, a Mammalia</p>
                      <p> Magasság 60-110 cm</p>
                      <p> Súlya 16-21 kg</p>
                      <p> Élőhelye: Afrika</p>  
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-12.jpg" alt="" title="Portfolio Image 11" />
                </div>	
              </div>
			   <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                      <p> Nemének tudományos neve, a Ciconia ciconia</p>
                      <p> Testhossza 100-110 cm</p>
                      <p> Súlya 3,4 kg</p>
                      <p> Élőhelye: Európa,Afrika</p>  
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-13.jpg" alt="" title="Portfolio Image 11" />
                </div>	
              </div>
			   <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                     <p> Nemének tudományos neve, a Testudo hermanni</p>
                      <p> Testhossza 12-13 cm</p>
                      <p> Súlya 1-1,5 kg</p>
                      <p> Élőhelye: Európa</p> 
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-14.jpg" alt="" title="Portfolio Image 11" />
                </div>	
              </div>
			   <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                      <p> Nemének tudományos neve, az Aquila chrysaetos</p>
                      <p> Testhossza 66-10 cm</p>
                      <p> Súlya 3-7 kg</p>
                      <p> Élőhelye: Európa,Ázsia,Amerika</p> 
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-15.jpg" alt="" title="Portfolio Image 11" />
                </div>	
              </div>
              <div class="s-12 m-6 l-3">
                <div class="image-with-hover-overlay image-hover-zoom margin-bottom">
                  <div class="image-hover-overlay background-primary"> 
                    <div class="image-hover-overlay-content text-center padding-2x">
                      <p> Nemének tudományos neve, a Struthio camelus</p>
                      <p> Magassága 2-2,8 m</p>
                      <p> Súlya 100-120 kg</p>
                      <p> Élőhelye: Afrika</p> 
                    </div> 
                  </div> 
                  <img src="img/portfolio/thumb-16.jpg" alt="" title="Portfolio Image 12" />
                </div>	
              </div>
            </div>  
          </div>
        </div> 
      </article>
    </main>
    
        <!-- FOOTER -->
    <?php print_html("html/footer.html"); ?>