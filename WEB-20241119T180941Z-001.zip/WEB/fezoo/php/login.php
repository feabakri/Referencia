<?php 
require_once '../config/connect.php';
require_once '../config/functions.php';

if (isset($_POST['login'])){
    $username = $_POST['username'];
    $psw = $_POST['psw'];
    $sql = "SELECT azonosito,felhasznalonev,jelszo FROM felhasznalok WHERE felhasznalonev = ? AND jelszo = ?";
    $stmt = $conn -> prepare($sql);
    $stmt -> bind_param("ss",$username, $psw);
    $stmt -> execute();
    $stmt -> store_result();
    if ($stmt -> num_rows == 1){
        $stmt -> bind_result($azonosito, $felhasznalonev, $jelszo);
        $stmt -> fetch();
        $_SESSION['userid'] = $azonosito;
    } else {
        echo "nem";
    }
    $stmt ->close();
}
$conn -> close();





?>