<?php
require_once '../config/connect.php';
require_once '../config/functions.php';

unset($_SESSION["userid"]);
header("Location: ../index.php");


?>

