$(document).ready(function(){
    $(document).on("click",".login",function(){
        let username = $("#username").val();
        let psw = $("#psw").val();
        username = username.trim();
        psw = psw.trim();
        if (username.length > 0 && psw.length > 0){
            $.ajax({
                url: "php/login.php",
                method: "POST",
                data: {username : username, psw: psw, login: 1},
                success: function(valasz){
					location.reload();
                },
                error: function(status){}
            });
        }
		else{
		console.log("hiba");
		
		
	}
        
    });

});