<?php
require_once 'config/connect.php';
require_once 'config/functions.php';



menu()
?>

    <!-- MAIN -->
    <main role="main">
      <!-- Content -->
      <article>
        <header class="section background-primary text-center">
            <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1">Megrendelések</h1>
        </header>
        <div class="section background-white"> 
          <div class="line">
  <?php


$sql = "SELECT azonosito, tipus, fajta, kor, nev, darab FROM megrendelesek";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>Azonosító</th><th>Típus</th><th>Fajta</th><th>Kor</th><th>Név</th><th>Darab</th</tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["azonosito"]. "</td><td>" . $row["tipus"]. "</td><td>" . $row["fajta"]. "</td><td>" . $row["kor"]. "</td><td>" . $row["nev"]. "</td><td>" . $row["darab"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
  if(isset($_POST['save']))
{
    $sql = "INSERT INTO megrendelesek ( tipus, fajta, kor,nev,darab)
    VALUES ('".$_POST["tipus"]."','".$_POST["fajta"]."','".$_POST["kor"]."','".$_POST["nev"]."','".$_POST["darab"]."')";

    $result = mysqli_query($conn,$sql);
	header("Refresh:0");
}


$conn->close();



  print_html("html/order.html")?>



          </div>
          
        </div> 
      </article>
    </main>
    
    <!--FOOTER -->
  <?php print_html("html/footer.html"); ?>