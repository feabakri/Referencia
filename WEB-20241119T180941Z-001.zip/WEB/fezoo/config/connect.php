<?php
session_start();
$server = "localhost";
$user = "root";
$pwd = "";
$dbName = "fezoo";
$port = "3306";

$conn = new mysqli($server, $user, $pwd, $dbName, $port);

if ($conn -> connect_errno){
    die("Hiba a kapcsolat során! ".$conn->connect_error);
}
$conn -> set_charset("utf8");
?>
