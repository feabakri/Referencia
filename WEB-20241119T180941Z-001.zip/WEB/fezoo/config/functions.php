<?php

function dd($var){
    var_dump($var);
    die();
}


function print_html($html) {
    echo file_get_contents($html);
}

function is_logged() {
    if (isset($_SESSION['userid'])) {
        return true;
    } else {
        return false;
    }
}

function menu(){
    $menu = file_get_contents("html/header.html");
    if (is_logged()) {
        $menu = str_replace(["::login::","::megrendelesek::"], [file_get_contents("html/logout.html"),"<li><a href='orders.php'>Megrendelés</a></li>"], $menu);

    } 
	else {
        $menu = str_replace(["::login::","::megrendelesek::"], [file_get_contents("html/loginform.html"),""], $menu);

    }
	echo $menu;
}