<?php
require_once 'config/connect.php';
require_once 'config/functions.php';
  menu()
?>
   
    <!-- MAIN -->
    <div role="main">
     
      
      <!-- Section 1 -->
      <section class="section background-white"> 
        <div class="line">
          <div class="margin">
            <div class="s-12 m-12 l-4 margin-m-bottom">
              <img class="margin-bottom" src="img/oroszlan.jpg" alt="">
              <h2 class="text-thin">Kagura</h2>
              <p>Duislsdjfalésdjfléasjdflasdlfalésdl.</p> 
                             
            </div>
            <div class="s-12 m-12 l-4 margin-m-bottom">
              <img class="margin-bottom" src="img/zebra.jpg" alt="">
              <h2 class="text-thin">Valír</h2>
              <p>Duis .</p> 
                        
            </div>
            <div class="s-12 m-12 l-4 margin-m-bottom">
              <img class="margin-bottom" src="img/tigris.jpg" alt="">
              <h2 class="text-thin">Zakariás</h2>
              <p>Duis </p> 
                          
            </div>
			
          </div>
        </div>
      </section>
	  
      
      
      
      
      <!-- Section 3 -->
      <section class="section background-white">
        <div class="full-width text-center">
          <img class="center margin-bottom-30" style="margin-top: -210px;" src="img/térkép.jpg" height="50%" alt="">
          <div class="line">
            <h2 class="headline text-thin text-s-size-30"> <span class="text-primary"></span>A Föld állatvilága térkép </h2>
            <p class="text-size-20 text-s-size-16 text-thin"></p>
            
            <p class="text-size-20 text-s-size-16 text-thin text-primary"></p>
          </div>  
        </div>  
      </section>
      <hr class="break margin-top-bottom-0">
      

      
    </div>
    
    <!-- FOOTER -->
<?php print_html("html/footer.html"); ?>