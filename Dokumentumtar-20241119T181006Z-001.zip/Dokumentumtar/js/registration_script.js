function validalas(){
    var username = document.getElementById("userName").value;
    var password = document.getElementById("userPassword").value;
    var emailaddress = document.getElementById("emailAddress").value;
    var usernameReg = /^[a-zA-Z0-9]+$/;
    var passwordReg = /^[a-zA-Z0-9]+$/;
    var emailReg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    
  
    if (emailaddress == "")
    {
        alert("Az email mező nem maradhat üresen!")
    }

    else if (username == ""){
      alert("A felhasználónév mező nem maradhat üresen!");
    }
  
    else if (password == "")
    {
      alert("A jelszó mező nem maradhat üresen!");
    }

    else if (!emailReg.test(emailaddress))
    {
        alert("Az emailcím nem felel meg a feltételeknek!")
    }

    else if(!usernameReg.test(username))
    {
      alert("A felhasználónév nem felel meg a feltételeknek!");
    }
    else if(!passwordReg.test(password))
    {
      alert("A jelszó nem felel meg a feltételeknek!");
    }
  
    else{
      window.location.replace("../html/login_index.html");
      return false;
        
    }
  }
  
  