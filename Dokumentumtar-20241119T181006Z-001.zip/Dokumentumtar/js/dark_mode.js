var loginbutton = document.getElementById('login');
var background = document.body;
var wrapper = document.getElementsByClassName('wrapper');
var button = document.getElementsByClassName('registrationbutton');

function dark(){

    if(background.style.backgroundColor != "black"){
        loginbutton.style.backgroundColor = "#3b3a3a";
        background.style.backgroundColor = "black";
        button[0].style.color = "#3b3a3a";
    }
    else{
        background.style.backgroundColor = "#f2f2f2";
        loginbutton.style.backgroundColor = "#0094a8";
        wrapper[0].style.backgroundColor = "white";

    }
    
    
    
}