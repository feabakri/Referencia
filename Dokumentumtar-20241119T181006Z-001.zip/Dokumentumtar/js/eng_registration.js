function validalas(){
    var username = document.getElementById("userName").value;
    var password = document.getElementById("userPassword").value;
    var emailaddress = document.getElementById("emailAddress").value;
    var usernameReg = /^[a-zA-Z0-9]+$/;
    var passwordReg = /^[a-zA-Z0-9]+$/;
    var emailReg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    
  
    if (emailaddress == "")
    {
        alert("You have to fill the email field!")
    }

    else if (username == ""){
      alert("You have to fill the username field!");
    }
  
    else if (password == "")
    {
      alert("You have to fill the password field!");
    }

    else if (!emailReg.test(emailaddress))
    {
        alert("The email address doesn't meet the requirements!")
    }

    else if(!usernameReg.test(username))
    {
      alert("The username doesn't meet the requirements!");
    }
    else if(!passwordReg.test(password))
    {
      alert("The password doesn't meet the requirements!");
    }
  
    else{
      window.location.replace("../html/login_english.html");
      return false;
        
    }
  }
  
  