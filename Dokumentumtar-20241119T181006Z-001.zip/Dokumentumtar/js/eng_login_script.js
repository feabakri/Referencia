function validalas(){
    var username = document.getElementById("userName").value;
    var password = document.getElementById("userPassword").value;
    var usernameReg = /^[a-zA-Z0-9]+$/;
    var passwordReg = /^[a-zA-Z0-9]+$/;
    
  
    if (username == ""){
      alert("You have to fill the username field!");
    }
  
    else if (password == "")
    {
      alert("You have to fill the password field!");
    }
      
    else if(!usernameReg.test(username))
    {
      alert("The username doesn't meet the requirements!");
    }
    else if(!passwordReg.test(password))
    {
      alert("The password doesn't meet the requirements!");
    }
  
    else{
      window.location.replace("../html/dokumentumtar.html");
      return false;
        
    }
  }
  
  